// cmpt225postfix.cpp : Defines the entry point for the console application.
//

#include <iostream>
#include <string>
#include <stdlib.h> 
#include "simplestack.h"

using namespace std;

// Forward Declarations
string GetNext(string input, int& pos);
int PostFixCalculator(string exp);
void PostFixTest(string exp);
void PostFixExample();
void CopyConstructorTest();
void AssignmentOperatorTest();
void RemovePrintStack(SimpleStack st);

int main()
{
	PostFixExample();
	CopyConstructorTest();
	AssignmentOperatorTest();

	
	cout << endl << endl;
	return 0;
}

// Parses a RPN string, returning the next operand or operator from
// the given position
// PRE: input is in the correct format
// PARAM: input - the RPN string
//        pos - the position to start parsing from
// Format: the string should contain a series of integer operands and 
//         the +, - * and / operators separated by spaces
string GetNext(string input, int& pos){
	string result = "";
	int nextSpace = 0;
	// Ignore current space (given by pos)
	if(pos > 0){
		pos++;
	}
	if (pos < input.size()){
		// Find next space
		nextSpace = input.find(" ", pos+1);
		// DEBUG
		// cout << "nextSpace = " << nextSpace << endl;
		// END DEBUG
		result = input.substr(pos, nextSpace - pos);
		pos = nextSpace;
	}
	return result;
}

// Calculates and returns the result of a RPN expression
// PRE: input is in the correct format
// PARAM: exp - the RPN string
int PostFixCalculator(string exp){
	// Initialize variables
	int pos = 0; // For parsing exp
	string next = ""; // Next operand or operator
	SimpleStack st(exp.size());
	int leftOp = 0;
	int rightOp = 0;

	// Process each operator or operand
	while (pos != -1){
		next = GetNext(exp, pos);
		// DEBUG
		// cout << "next op: " << next << endl;
		// END DEBUG

		// Push operand onto stack
		if(next != "+" && next != "-" && next != "/" && next != "*"){
			st.Push(atoi(next.c_str()));
		}
		// Or process each operator
		else{
			rightOp = st.Pop();
			leftOp = st.Pop();
			// DEBUG
			cout << leftOp << " " << next << " " << rightOp << endl;
			// END DEBUG
			if(next == "+"){ // +
				st.Push(leftOp + rightOp);
			} else if(next == "-"){ // -
				st.Push(leftOp - rightOp);
			} else if(next == "*"){ // *
				st.Push(leftOp * rightOp);
			} else if(next == "/"){ // /
				st.Push(leftOp / rightOp);
			} 
		}
	}

	// Return result
	return st.Pop();
}

// Test function for the postFixCalculator function
void PostFixTest(string exp)
{
	int result = PostFixCalculator(exp);
	cout << exp << " = " << result;
}

// Calls postFixTest three times
void PostFixExample()
{
	cout << "POSTFIX TEST" << endl << endl;
	PostFixTest("5 1 2 + 4 * + 3 -");
	cout << endl << endl;
	PostFixTest("9 7 + 5 3 - /");
	cout << endl << endl;
	PostFixTest("3 5 2 * 17 7 - + * 11 3 * -");
	cout << endl << "END POSTFIX TEST" << endl << endl;
}

// Quick and dirty copy construcotr / assignment operator test
void CopyConstructorTest()
{
	cout << "CONSTRUCTOR TEST" << endl << endl;
	SimpleStack st1;

	st1.Push(1);
	st1.Push(2);
	st1.Push(3);

	SimpleStack st2(st1); //call copy constructor

	// Empty st1, shoudn't do anything to st2
	cout << "Empty st1" << endl;
	while(st1.Size() > 0){
		cout << st1.Pop() << endl;
	}
	
	// Call removePrintStack to print st2, and to
	// use copy constructor again
	cout << endl << "Pass st2 to removePrintStack (by value)" << endl;
	RemovePrintStack(st2);

	// Empty st2
	cout << endl << "Empty st2" << endl;
	while(st2.Size() > 0){
		cout << st2.Pop() << endl;
	}

	// Tests error handling by removing from an empty stack
	cout << endl << "Call pop on empty st1" << endl;
	try{		
		cout << st1.Pop() << endl;
	}catch(runtime_error e){
		cout << e.what() << endl;
	}

	cout << endl << "END CONSTRUCTOR TEST" << endl << endl;
}

// Quick and dirty copy construcotr / assignment operator test
void AssignmentOperatorTest()
{
	cout << "ASSIGNMENT TEST" << endl << endl;

	SimpleStack st1;
	SimpleStack st2;
	SimpleStack st3;

	cout << "Insert 1 -3 in st1, 100 - 102 in st2" << endl;
	st1.Push(1);
	st1.Push(2);
	st1.Push(3);
	st2.Push(100);
	st2.Push(101);
	st2.Push(102);

	cout << endl << "st 3 = st2 = st1" << endl;
	st3 = st2 = st1; //tests return value of op=
	
	// Empty st1, shoudn't do anything to st2 or st3
	cout << endl << "Empty st1" << endl;
	while(st1.Size() > 0){
		cout << st1.Pop() << endl;
	}

	// Empty st2
	cout << endl << "Empty st2" << endl;
	while(st2.Size() > 0){
		cout << st2.Pop() << endl;
	}
	
	cout << endl << "st 3 = st3 - shoudn't destroy stack!" << endl;
	st3 = st3; //tests op= doesn't fail on self-assignment
	// Empty st3
	cout << endl << "Empty st3" << endl;
	while(st3.Size() > 0){
		cout << st3.Pop() << endl;
	}

	cout << endl << "END ASSIGNMENT TEST" << endl;
}

// Removes items from a copy of parameter (pass-by-value)
void RemovePrintStack(SimpleStack st)
{
	while(st.Size() > 0){
		cout << st.Pop() << endl;
	}
}



