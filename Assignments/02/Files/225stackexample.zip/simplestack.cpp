// File:        simplestack.cpp
// Author:      John Edgar / Geoffrey Tien
// Description: Example implementation for a limited-functionality stack class

#include "simplestack.h"

/////////////////////////////////////////////////////////////////////////
// Dynamic array implementation
/////////////////////////////////////////////////////////////////////////

// Default constructor
//SimpleStack::SimpleStack()
//{
//  arr_size = 2;
//  arr = new int[arr_size];
//  top = 0;
//}
//
//// Parameterized constructor
//SimpleStack::SimpleStack(int size)
//{
//  arr_size = size;
//  arr = new int[arr_size];
//  top = 0;
//}
//
//// Copy constructor
//SimpleStack::SimpleStack(const SimpleStack & st)
//{
//	CopyStack(st);
//}
//
//// Destructor
//SimpleStack::~SimpleStack()
//{
//  delete[] arr; // Release memory associated with dynamic array
//}
//
//// Inserts an int on the top of the stack
//// PARAM: x is the value to be inserted
//void SimpleStack::Push(int x)
//{
//  // if stack is full, we must make a new larger array and copy all existing contents
//  if (top == arr_size)
//  {
//    int* old_arr = arr;
//    arr_size = 2*arr_size;
//    arr = new int[arr_size];
//
//    for (int i = 0; i < top; i++)
//    {
//      arr[i] = old_arr[i];
//    }
//    delete[] old_arr;
//  }
//  // insert the item
//  arr[top] = x;
//  top += 1;
//}
//
//// Removes and returns the item at the top of the stack
//// Throws a runtime_error if the stack is empty
//int SimpleStack::Pop()
//{
//  if (top == 0) throw runtime_error("stack is empty");
//  top -= 1;
//  return arr[top];
//}
//
//// Returns the item at the top of the stack
//// Throws a runtime_error if the stack is empty
//int SimpleStack::Peek() const
//{
//  if (top == 0) throw runtime_error("stack is empty");
//  return arr[top-1];
//}
//
//// Returns the number of items in the stack
//// Not the size of the underlying array
//int SimpleStack::Size() const
//{
//	return top;
//}
//
//// Overloaded assignment operator - required because the class
//// allocates space in main memory
//// must work correctly for:
//// st2 = st1 --> general case, including when st1 is empty
//// st2 = st2 --> don't do anything in this case!
//// st3 = st2 = st1 --> must return a SimpleStack
//SimpleStack& SimpleStack::operator=(const SimpleStack& st)
//{
//	// Only copy the stack if it is a different object
//	// The this pointer is the address of the calling object
//	// i.e. if(calling object is not the parameter)
//	if (this != &st)
//  {
//		delete[] arr; //deallocate dynamic memory
//		CopyStack(st); //build new stack
//	}
//	return *this; //dereference pointer
//}
//
//// Copies the parameter into the calling object - makes
//// a deep copy.  Helper method for the copy constructor
//// and assignment operator.
//void SimpleStack::CopyStack(const SimpleStack& st)
//{
//	top = st.top;
//	arr_size = st.arr_size;
//
//	arr = new int[arr_size];
//
//	// Copy the contents of the array
//	for(int i=0; i < top; i++){
//		arr[i] = st.arr[i];
//	}
//}

/////////////////////////////////////////////////////////////////////////
// Linked List implementation
/////////////////////////////////////////////////////////////////////////

// Default constructor
SimpleStack::SimpleStack()
{
  top = NULL;
  n = 0;
}

// Parameterized constructor - required for compliance with array version
SimpleStack::SimpleStack(int sz)
{
	top = NULL;
	n = 0;
}

// Copy constructor - required since the class allocates
// space in dynamic memory and must therefore make a deep copy
// Note the parameter is a constant reference parameter
SimpleStack::SimpleStack(const SimpleStack& st)
{
	CopyStack(st); //builds new stack
}

// Destructor
SimpleStack::~SimpleStack()
{
  DeleteStack();
}

// Inserts an int on the top of the stack
// PARAM: x is the value to be inserted
void SimpleStack::Push(int x)
{
  Node* temp = new Node(x, top);
  top = temp;
  n++;
}

// Removes and returns the item at the top of the stack
// Throws a runtime_error if the stack is empty
int SimpleStack::Pop()
{
  // Check to see if stack is empty
  if (top == NULL) throw runtime_error("stack is empty");
  
  Node* temp = top; //save for deletion step
  n--;
  int result = temp->data; //save value for returning
  top = top->next;
  delete temp;
  return result;	
}

// Returns the item at the top of the stack
// Throws a runtime_error if the stack is empty
int SimpleStack::Peek() const
{
  if (top == NULL) throw runtime_error("stack is empty");
  return top->data;
}

// Returns the number of items in the stack
// Not the size of the underlying array
int SimpleStack::Size() const
{
	return n;
}

// Overloaded assignment operator - required because the class
// allocates space in main memory
// must work correctly for:
// st2 = st1 --> general case, including when st1 is empty
// st2 = st2 --> don't do anything in this case!
// st3 = st2 = st1 --> must return a MyStack
SimpleStack& SimpleStack::operator=(const SimpleStack& st)
{
	// Only copy the stack if it is a different object
	// The this pointer is the address of the calling object
	// i.e. if(calling object is not the parameter)
	if (this != &st)
  {
		DeleteStack(); //deallocate dynamic memory
		CopyStack(st); //build new stack
	}
	return *this; //dereference pointer
}

// Helper method for destructor
// deletes all nodes in stack
void SimpleStack::DeleteStack()
{
  Node* temp = top;

  // iterate through list deleting nodes
  while (temp != NULL)
  {
    temp = top->next;
    delete top;
    top = temp;
  }
  top = NULL;
}

// Copies the parameter into the calling object - makes
// a deep copy.  Helper method for the copy constructor
// and assignment operator.
void SimpleStack::CopyStack(const SimpleStack& st)
{
	top = NULL;
	n = st.n;
	// Only make a copy if st is non-empty
	if(st.top != NULL){
		// Make a copy of the parameter
		Node* original = st.top;
		Node* copy;
		// First copy the top
		copy = new Node(original->data, NULL);
		top = copy;
		original = original->next;

		// Now copy the rest of the stack
		while(original != NULL){
			copy->next = new Node(original->data, NULL);
			copy = copy->next;
			original = original->next;
		}
	}
}