// File:        simplestack.h
// Author:      John Edgar / Geoffrey Tien
// Description: Example header file for a limited-functionality stack class

#pragma once
#include <cstdlib> // needed for NULL definition
#include <stdexcept>

using namespace std;

class SimpleStack
{
  public:
    // Default constructor
    SimpleStack();

    // Parameterized constructor
    SimpleStack(int size);

    // Copy constructor
    SimpleStack(const SimpleStack& st);

    // Destructor
    ~SimpleStack();

    // Inserts an int on the top of the stack
	  // PARAM: x is the value to be inserted
	  void Push(int x);

    // Removes and returns the item at the top of the stack
	  // Throws a runtime_error if the stack is empty
	  int Pop();

    // Returns the item at the top of the stack
	  // Throws a runtime_error if the stack is empty
	  int Peek() const;

    // Returns the number of items in the stack
	  int Size() const;

    // Overloaded operators
    SimpleStack& operator=(const SimpleStack& st);

  private:
    // Helper function for copy constructor and assignment operator
    void CopyStack(const SimpleStack& st);

    //////////////////////////////////////////////////////////////////
    // dynamic array implementation
    /////////////////////////////////////////////////////////////////
    //int arr_size; // maximum size of dynamic array
    //int* arr;     // pointer to dynamic array
    //int top;      // using an integer array index to track top of stack

    ///////////////////////////////////////////////////////////////
    // linked list implementation
    ////////////////////////////////////////////////////////////////
    class Node
    {
      public:
        int data;
        Node* next;
        // Parameterized constructor
        Node(int x, Node* nd) : data(x), next(nd) {};
    };

    int n; // number of items in stack
    Node* top;
    void DeleteStack(); // helper method for destructor
};