/*
 * A simple complaint queue
 */

#include "ccqueue.h"

CCQueue::CCQueue()
{

}

bool CCQueue::Add(string customer, string complaint)
{
	return false;
}

Ticket CCQueue::Service()
{
	return Ticket();
}

bool CCQueue::MoveUp(int index)
{
	return false;
}

bool CCQueue::MoveDown(int index)
{
	return false;
}

int CCQueue::Size() const
{
	return 0;
}
