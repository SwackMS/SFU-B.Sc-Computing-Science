/*
 * A simple linked list class
 */

#ifdef _DLINKEDLIST_H_

//Default constructor
template <class T>
DLinkedList<T>::DLinkedList()
{

}

//Copy constructor
template <class T>
DLinkedList<T>::DLinkedList(const DLinkedList& ll)
{

}

//Private
template <class T>
void DLinkedList<T>::CopyList(const DLinkedList& ll)
{

}

//Private
template <class T>
void DLinkedList<T>::DeleteList()
{

}

//Desctructor
template <class T>
DLinkedList<T>::~DLinkedList()
{

}

template <class T>
void DLinkedList<T>::InsertFront(T item)
{

}

template <class T>
void DLinkedList<T>::InsertBack(T item)
{

}

template <class T>
void DLinkedList<T>::InsertAt(T item, int p)
{

}

template <class T>
T DLinkedList<T>::RemoveAt(int p)
{

}

template <class T>
void DLinkedList<T>::RemoveDuplicates()
{

}

template <class T>
int DLinkedList<T>::Size() const
{

}

template <class T>
bool DLinkedList<T>::IsEmpty() const
{

}

template <class T>
bool DLinkedList<T>::Contains(T item) const
{

}

template <class T>
T DLinkedList<T>::ElementAt(int p) const
{

}

//Overloaded assignment (=) operator
template <class T>
DLinkedList<T>& DLinkedList<T>::operator=(const DLinkedList<T>& ll)
{

}

#endif
