// File:        redblacktree.h
// Author:      Justin Mang and Praneet Atwal
// Date:        2016-03-17
// Description: Implementation of a RedBlackTree class and template Node class for use with CMPT 225 assignment #4

#ifdef _REDBLACKTREE_H_

#include <cstdlib>
#include <stdexcept>
#include <string>
#include <algorithm>
using namespace std;

// recursive helper function for deep copy
// creates a new node based on sourcenode's contents, links back to parentnode,
//   and recurses to create left and right children
template <class T>
Node<T>* RedBlackTree<T>::CopyTree(Node<T>* sourcenode, Node<T>* parentnode)
{

	//TODO: Actual implementation of a new node
	if (node != NULL)
		{
		// recurse on left child
		if (node->left != NULL)
			InOrder(node->left, arr, arrsize, index);

		// visit current node
		arr[index] = node->data;
		index++;

		// recurse on right child
		if (node->right != NULL)
			InOrder(node->right, arr, arrsize, index);
		}
}

// recursive helper function for tree deletion
// deallocates nodes in post-order
template <class T>
void RedBlackTree<T>::RemoveAll(Node<T>* node)
{
	if(node != NULL)
	{
		RemoveAll(node->left);
		RemoveAll(node->right);
		delete node;
	}
}
	
// Tree fix, performed after removal of a black node
// Note that the parameter x may be NULL
template <class T>
void RedBlackTree<T>::RBDeleteFixUp(Node<T>* x, Node<T>* xparent, bool xisleftchild)
{
	//TODO: determine if violations occur after deletion and fix accordingly
}

// Calculates the height of the tree
// Requires a traversal of the tree, O(n)
template <class T>
int RedBlackTree<T>::CalculateHeight(Node<T>* node) const
{
	if (node == NULL)
		return -1;

	return 1 + max(CalculateHeight(node->left), CalculateHeight(node->right));
}


// default constructor
template <class T>
RedBlackTree<T>::RedBlackTree()
{
	root = NULL;
	size = 0;
}

// copy constructor, performs deep copy of parameter
template <class T>
RedBlackTree<T>::RedBlackTree(const RedBlackTree<T>& rbtree)
{
//	CopyTree(rbtree, root);
}

// destructor
// Must deallocate memory associated with all nodes in tree
template <class T>
RedBlackTree<T>::~RedBlackTree()
{
	if(root != NULL)
		RemoveAll(root);
}

// overloaded assignment operator
template <class T>
RedBlackTree<T>& RedBlackTree<T>::operator=(const RedBlackTree<T>& rbtree)
{
	//TODO: is return parameter correct?
	int t = rbtree.size;
	if(rbtree.size == size)
	{
		T* temp1 = Dump(size);
		T* temp2 = rbtree.Dump(t);
		int i = 0;
		while (i < size)
		{
			if(temp1[i] != temp2[i])
				return *this;
			i += 1;
		}
	}
	return *this;
}

// Accessor functions

// Calls BSTInsert and then performs any necessary tree fixing.
// If item already exists, do not insert and return false.
// Otherwise, insert, increment size, and return true.
template <class T>
bool RedBlackTree<T>::Insert(T item)
{
	//TODO: No tree fix implemented

	if(!Search(item))//if item does not exist then
	{
		BSTInsert(item);//insert item
		size += 1;
		return true;
	} 
	else
		return false;
}

// Removal of an item from the tree.
// Must deallocate deleted node after RBDeleteFixUp returns
template <class T>
bool RedBlackTree<T>::Remove(T item)
{
	//TODO: Syntax incorrect? Logically sound?
	/**
	//delete node and replace with predecessor
	if(Search(item))
	{
		//if not leaf node (node has children)
		if(item->left != NULL && item->right != NULL)
		{
			//find replacement node
			Node<T> *pred = Predecessor(item);
			if(pred.p->left == item)
				pred.p.left = pred;
			else
				pred.p.right = pred;
			pred.p = item.p;
			pred.left = item.left;
			pred.right = item.right;
			if(item.p->left == item)
				item.p.left = pred;
			else
				item.p.right = pred;
			if(item.left != NULL)
			item.left.p = pred;
			if(item.right != NULL)
			item.right.p = pred;
			delete item.data;
		}
	}*/
	return false;
}

// deletes all nodes in the tree. Calls recursive helper function.
template <class T>
void RedBlackTree<T>::RemoveAll()
{
	RemoveAll(root);
}

// returns the number of items in the tree
template <class T>
int RedBlackTree<T>::Size() const
{
	return size;
}

// returns the height of the tree, from root to deepest null child. Calls recursive helper function.
// Note that an empty tree should have a height of 0, and a tree with only one node will have a height of 1.
template <class T>
int RedBlackTree<T>::Height() const
{
	if(root == NULL)
		return 0;
	else
	{
		return CalculateHeight(root);
	}
}

#endif